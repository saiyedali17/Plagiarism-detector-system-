# Plagiarsim Checker

Plagiarsim checker using cosine algorithm


## How to Run?

- Install the requirements using `pip install -r requirements.txt`
- Run server `python manage.py runserver`



### Results
<table>
  <tr>
    <td>Plagiarsim Checker</td>
  </tr>
  <tr>
    <td><img src="https://github.com/noorkhokhar99/Plagiarsim-Checker/blob/main/Modern%20Minimalist%20Simple%20Technology%20Facebook%20Cover.png"></td>
  </tr>
 </table>
